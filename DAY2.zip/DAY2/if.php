<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        $t = 40;
        if ( $t >= "50"){
            echo "less than 50";
        }
        elseif ( $t = "40"){
            echo "is 40";
        }
        else{
            echo "less than 40 ";
        }

    ?>
</body>
</html>